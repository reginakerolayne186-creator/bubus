# TaskFlow — Template de gerenciamento de tarefas

Template web inspirado no exercício Python de lista de tarefas.

## Funcionalidades
- Cadastro e login demonstrativos.
- Perfil administrador e usuário comum.
- Criar, listar, concluir/reabrir e excluir tarefas.
- Usuário comum visualiza somente as próprias tarefas.
- Administrador visualiza todas as tarefas e a lista de usuários.
- Filtros: todas, pendentes e concluídas.
- Contadores e layout responsivo para celular e computador.
- Persistência local com `localStorage`.

## Como executar
Abra `index.html` no navegador. Não precisa instalar bibliotecas.

## Acesso inicial
- Login: `admin`
- Senha: `admin123`

## Publicar no GitHub Pages
1. Crie um repositório no GitHub.
2. Envie `index.html`, `css/`, `js/` e `README.md` para a raiz do repositório.
3. Acesse **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`, depois salve.
6. Aguarde a publicação e copie o endereço exibido em Settings → Pages.

## Aviso importante
Este projeto é um protótipo didático front-end. As senhas e os dados são armazenados no `localStorage` do navegador e não oferecem segurança real. Para uso real, implemente autenticação e banco de dados em um servidor.
