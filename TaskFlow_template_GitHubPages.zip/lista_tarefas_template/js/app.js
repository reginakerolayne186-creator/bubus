const STORAGE_KEY = "taskflow_demo_v1";
const defaultData = {
  users: [{id:1,name:"Administrador",login:"admin",password:"admin123",role:"admin"}],
  tasks: [], nextUserId:2, nextTaskId:1
};
let data = loadData();
let currentUser = null;
let currentFilter = "all";

function loadData(){
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || structuredClone(defaultData); }
  catch { return structuredClone(defaultData); }
}
function saveData(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); }
function byId(id){ return document.getElementById(id); }
function showMessage(message, good=false){
  byId("authMessage").textContent = message;
  byId("authMessage").style.color = good ? "#29976d" : "#c65d5d";
}
function setAuthTab(tab){
  document.querySelectorAll(".auth-tab").forEach(b=>b.classList.toggle("active",b.dataset.auth===tab));
  byId("loginForm").classList.toggle("hidden",tab!=="login");
  byId("registerForm").classList.toggle("hidden",tab!=="register");
  showMessage("");
}
document.querySelectorAll(".auth-tab").forEach(b=>b.addEventListener("click",()=>setAuthTab(b.dataset.auth)));

byId("loginForm").addEventListener("submit",e=>{
  e.preventDefault();
  const login=byId("loginUser").value.trim();
  const password=byId("loginPassword").value;
  const user=data.users.find(u=>u.login.toLowerCase()===login.toLowerCase() && u.password===password);
  if(!user){showMessage("Login ou senha incorretos.");return;}
  currentUser=user; renderApp();
});
byId("registerForm").addEventListener("submit",e=>{
  e.preventDefault();
  const name=byId("registerName").value.trim();
  const login=byId("registerUser").value.trim();
  const password=byId("registerPassword").value;
  if(data.users.some(u=>u.login.toLowerCase()===login.toLowerCase())){showMessage("Esse login já está em uso.");return;}
  if(password.length<7){showMessage("A senha precisa ter ao menos 7 caracteres.");return;}
  const user={id:data.nextUserId++,name,login,password,role:"usuario"};
  data.users.push(user);saveData();
  byId("registerForm").reset();setAuthTab("login");showMessage("Cadastro realizado! Agora entre na sua conta.",true);
});
byId("logoutBtn").addEventListener("click",()=>{
  currentUser=null;byId("authView").classList.remove("hidden");
  byId("tasksView").classList.add("hidden");byId("usersView").classList.add("hidden");
  document.querySelector(".topbar").classList.add("hidden");byId("logoutBtn").classList.add("hidden");
});
function renderApp(){
  byId("authView").classList.add("hidden");byId("tasksView").classList.remove("hidden");
  document.querySelector(".topbar").classList.remove("hidden");byId("logoutBtn").classList.remove("hidden");
  byId("userName").textContent=currentUser.name;byId("userRole").textContent=currentUser.role==="admin"?"Administrador":"Usuário";
  byId("userAvatar").textContent=currentUser.name.charAt(0).toUpperCase();
  byId("welcomeTitle").textContent=`Olá, ${currentUser.name.split(" ")[0]}!`;
  byId("todayDate").textContent=new Intl.DateTimeFormat("pt-BR",{dateStyle:"full"}).format(new Date());
  document.querySelectorAll(".admin-only").forEach(el=>el.classList.toggle("hidden",currentUser.role!=="admin"));
  showView("tasks");renderTasks();
}
function showView(view){
  byId("tasksView").classList.toggle("hidden",view!=="tasks");
  byId("usersView").classList.toggle("hidden",view!=="users");
  byId("pageTitle").textContent=view==="users"?"Usuários":"Minhas tarefas";
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
  if(view==="users" && currentUser?.role==="admin")renderUsers();
}
document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
byId("taskForm").addEventListener("submit",e=>{
  e.preventDefault();const title=byId("taskTitle").value.trim();if(!title)return;
  data.tasks.push({id:data.nextTaskId++,title,done:false,userId:currentUser.id});
  saveData();byId("taskForm").reset();renderTasks();
});
document.querySelectorAll(".filter").forEach(b=>b.addEventListener("click",()=>{
  currentFilter=b.dataset.filter;
  document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderTasks();
}));
function visibleTasks(){
  return data.tasks.filter(t=>(currentUser.role==="admin"||t.userId===currentUser.id))
    .filter(t=>currentFilter==="all"||(currentFilter==="done"?t.done:!t.done));
}
function renderTasks(){
  const owned=data.tasks.filter(t=>currentUser.role==="admin"||t.userId===currentUser.id);
  byId("totalCount").textContent=owned.length;
  byId("pendingCount").textContent=owned.filter(t=>!t.done).length;
  byId("doneCount").textContent=owned.filter(t=>t.done).length;
  const list=byId("taskList");list.innerHTML="";
  visibleTasks().forEach(task=>{
    const row=document.createElement("div");row.className="task-row";
    const left=document.createElement("div");left.className="task-left";
    const check=document.createElement("input");check.type="checkbox";check.className="task-check";check.checked=task.done;check.setAttribute("aria-label","Marcar tarefa como concluída");
    check.addEventListener("change",()=>{task.done=check.checked;saveData();renderTasks();});
    const title=document.createElement("span");title.textContent=task.title;if(task.done)title.classList.add("done");
    left.append(check,title);
    if(currentUser.role==="admin"){const owner=data.users.find(u=>u.id===task.userId);const tag=document.createElement("small");tag.textContent=owner?` · ${owner.login}`:"";tag.style.color="#999";left.append(tag);}
    const del=document.createElement("button");del.className="delete-btn";del.textContent="Excluir";del.addEventListener("click",()=>{data.tasks=data.tasks.filter(t=>t.id!==task.id);saveData();renderTasks();});
    row.append(left,del);list.append(row);
  });
  byId("emptyState").classList.toggle("hidden",visibleTasks().length!==0);
}
function renderUsers(){
  const list=byId("usersList");list.innerHTML="";
  data.users.forEach(user=>{
    const row=document.createElement("div");row.className="user-row";
    const info=document.createElement("div");const name=document.createElement("strong");name.textContent=user.name;
    const login=document.createElement("small");login.textContent=`@${user.login}`;info.append(name,login);
    const role=document.createElement("span");role.className="role-tag";role.textContent=user.role==="admin"?"Administrador":"Usuário";
    row.append(info,role);list.append(row);
  });
}
byId("logoutBtn").classList.add("hidden");
document.querySelector(".topbar").classList.add("hidden");
saveData();
// Este é um protótipo front-end: autenticação e dados ficam apenas no navegador.
